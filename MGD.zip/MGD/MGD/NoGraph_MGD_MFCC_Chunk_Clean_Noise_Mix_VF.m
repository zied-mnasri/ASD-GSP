clear all
close all

addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\SVDD-MATLAB-master\')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\tSNE_matlab')

useTsneTrain=input('Apply t-SNE before training (0:No, 1:Yes) : ');
useTsneTest=input('Apply t-SNE after test (0:No, 1:Yes) : ');
useData=input('Use clean/noisy/mix outliers (0:Clean, 1:Noisy, 2:Mix): '); 

predictionMethod=input('Choose a prediction method (0: Kmeans (Casual!), 1:SVDD/OC-SVM, 2:FitcSVM/Bin-SVM, 3: Autoencoder) ')

%%%%%%%%% Load extracted features and labels %%%%%%%%%%%%%%%%%
framedur=input('Give frame duration (sec), e.g. 3 sec: ');
shift=input('Give shift rate (between 0.01 and 0.5): ');

dataDirectory=('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniLR\MGD\Data\');
switch useData
    case 0
        load ([dataDirectory,'Features_Labels_Clean\MFCC_Features_Labels_',num2str(framedur),'sec_clean.mat'])
   case 1
        noiseType=input('Give noise type ("white", "babble"): ')
        SNRdB=input('Give SNRdB: ')
        load ([dataDirectory,'Features_Labels_Noisy\MFCC_Features_Labels_',num2str(framedur),'sec_noisy_',noiseType,'_',num2str(SNRdB),'dB_Random.mat'])
     case 2
        load ([dataDirectory,'Features_Labels_Mix\MFCC_Features_Labels_',num2str(framedur),'sec_mix.mat'])
end
    
%%%%%%%% Labels %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numfiles=length(Genre);
numLabels=length(unique(Genre));

switch useData
    case 0 %In this workspace, choose the outlier genre
        outlier=input('Choose the outlier genre (blues,classical,country,disco,hiphop,jazz,metal,pop,reggae,rock): ');         
    case 1 %In this workspace, 'classical' signals are noisy %
        outlier='outlier';
    case 2 %In this workspace, 'genreMix' signals are outliers
        outlier='genres_mix';
end

switch useData
    case 0 %In this workspace, choose the outlier genre
        Label(Genre==outlier)=1;
        Label(Genre~=outlier)=0;
    case 1 %In this workspace, noisy signals are the outlier %
        Label(Outlierness==outlier)=1;
        Label(Outlierness~=outlier)=0;
    case 2 %In this workspace, 'genres_mix' signals are the outliers
        Label(Genre==outlier)=1;
        Label(Genre~=outlier)=0;
end

%%%%%%%% No Graph Features %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numfiles2=input(['Give the n. of audio files (max ',num2str(numfiles),') : '])
indexfiles=randi([1 numfiles], numfiles2,1);

WorkFeatures=(Features(indexfiles,:));
WorkLabels=Label(indexfiles).';
 
DcaseChunk =zeros(numfiles2,size(WorkFeatures,2));
for n=1:numfiles2
        display(['Processing file No ', num2str(n),' of ',num2str(numfiles2)])        
        s=WorkFeatures(n,:);              
        DcaseChunk(n,:)=reshape(s,size(s,1)*size(s,2),1);
        clear s 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Apply t-SNE for data distribution %%%%%%%%%%%%%%%
if (useTsneTrain==1)
    %Parameters
    no_dims=3;
    initial_dims=30;
    perplexity=30;
    labels=WorkLabels;
    %Apply tSNE
    mappedX=tsne(DcaseChunk,[],no_dims,initial_dims,perplexity);
    figure, gscatter(mappedX(:,1),mappedX(:,3),Label(indexfiles(1:numfiles2)));

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% Apply K-means %%%%%%%%%%%%%%%%%%%
if (predictionMethod==0)
    %[idx,Cent]=kmeans(DcaseChunk,2);
    [idx,Cent]=kmeans(DcaseChunk,2);
    Pred=idx-1;
    target=WorkLabels;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Apply SVDD for OC-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==1)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    trainData=data(randIdx(1:Trainsize),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainDataNormal = trainData(trainLabel == 1, :);
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    
    % parameter setting
    kernel = Kernel('type', 'gaussian', 'gamma', 0.04);
    cost = 0.3;
    svddParameter = struct('cost', cost,...
                           'kernelFunc', kernel);

    % creat an SVDD object
    svdd = BaseSVDD(svddParameter);
    % train SVDD model
    svdd.train(trainDataNormal, trainLabelNormal);
    % test SVDD model
    results = svdd.test(testData, testLabel);
    % Visualization 
    svplot = SvddVisualization();
    
    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    YPred = results.predictedLabel;
    Pred(YPred==-1)=1;
    Pred(YPred==1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);
    
    % Visualization 
    svplot = SvddVisualization();
    svplot.distance(svdd, results);
   
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Apply fitSVM for OC-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==2)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    
    trainData=data(randIdx(1:Trainsize),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;
    rng(1);
    SVMModel = fitcsvm(trainData,trainLabel,'KernelScale','auto','Standardize',true,...
    'OutlierFraction',0.1);
    
    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    

    svInd = SVMModel.IsSupportVector;
    [YPred,score] = predict(SVMModel,testData);
    Pred(YPred == -1)=1;
    Pred(YPred == 1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1); 
end

%%%%%%%%%%%% Method n.3-Apply AE for Anomaly Detection %%%%%%%%%%%%%%%%%%%
if (predictionMethod==3)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    
    trainData=data(randIdx(1:Trainsize),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainDataNormal = trainData(trainLabel == 1, :);
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;
    rng(1);

    % Defined the training and test data
    traindata_ae = trainData.';
    testdata_ae = testData.';

    %Setup Autoencoder options
    option.MaxEpochs = input('Give max epoch number: ');
    option.hiddenSize = input('Give number of hidden nodes: '); % number of hidden nodes, i.e. the dimension of the "code"
    option.L2WeightRegularization = 1.0e-10;
    option.SparsityRegularization = 1.0e-10;
    option.SparsityProportion = 0.7;
    option.ScaleData = true;
    option.UseGPU = false

    % Train the autoencoder
    autoenc = trainAutoencoder(traindata_ae, option.hiddenSize, ...
    'MaxEpochs', option.MaxEpochs, ...
    'L2WeightRegularization', option.L2WeightRegularization, ...
    'SparsityRegularization', option.SparsityRegularization, ...
    'SparsityProportion', option.SparsityProportion, ...
    'ScaleData', option.ScaleData, ...
    'UseGPU', option.UseGPU);

    %Do the encode-decode
    %Let's take one frame of data and feed it into the trained network. Let's then visualize the input, the code, the output and the error between input and output. We see that the trained network can reproduce the input pattern and noise is removed (autoencoders can also be used for denoising!)
    code = encode(autoenc,testdata_ae(:,1));
    decoded = decode(autoenc,code);
    tiledlayout('flow')
    nexttile
    plot(testdata_ae(:,1)),title('Input')
    nexttile
    plot(code),title('Code')
    nexttile
    plot(decoded),title('Output')
    nexttile
    plot(testdata_ae(:,1)-decoded), title('Error')
   
    %Calculate the error for the entire test set and visualize
    %Let's now test with the entire dataset and see if our network can spot the anomaly. And indeed wee see that it can.
    % Make a prediction with the entire test dataset
    y_hat = predict(autoenc, testdata_ae);
    % Calculate the error
    E1 = sqrt(sum((y_hat - testdata_ae).^2));
    X1_hat = y_hat(1, :);
    
    figure
    plot(1:size(E1,2), E1, 'LineWidth',1.5), legend('Error'), xlabel('test samples'), ylabel('RMSE')
        
    %Run the detector sample by sample
    %runDetection
    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    Tau = input('Give the AE error threshold: ')
    YPred = E1>Tau;
    Pred = YPred.';
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Calculate evaluation metrics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[c,CM,ind,per]=confusion(target',Pred');
display(['Confusion matrix = '])
CM

Acc=1-c;
display(['Accuracy = ',num2str(Acc)])

numClasses=max(WorkLabels)-min(WorkLabels)+1;
for i=1:numClasses
    Prec(i)=CM(i,i)/sum(CM(i,:));
    Rec(i)=CM(i,i)/sum(CM(:,i));
    F1(i)=2*Prec(i)*Rec(i)/(Prec(i)+Rec(i));    
end

Acc=trace(CM)/length(target);
display('Confusion matrix: ')
display(CM)

[tpr,fpr,thresholds] = roc(target',Pred');
figure
res=plotroc(target',Pred','grid');
grid on
auc=trapz([0,fpr,1],[0,tpr,1]);

Metrics=zeros(5,2)
Metrics(1,:)=[auc,0];
Metrics(2,:)=[Acc,0];
Metrics(3,:)=Prec;
Metrics(4,:)=Rec;
Metrics(5,:)=F1;
display(Metrics)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Apply tSNE for test Data %%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (useTsneTest==1)
    no_dims=3;
    initial_dims=min(length(target),30);
    perplexity=30;
    labels=target;
    mappedX=tsne(testData,[],no_dims,initial_dims,perplexity);
    figure, gscatter(mappedX(:,1),mappedX(:,2),labels);
    figure, gscatter(mappedX(:,1),mappedX(:,2),Pred);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
display(Metrics)