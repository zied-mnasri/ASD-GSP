clear all
close all

addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\SVDD-MATLAB-master\')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\tSNE_matlab')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\SVDD-MATLAB-master\SVDD-MATLAB-master\Svdd')

%graphType=input('Select a graph type (0: sensor, 1: path, 2: ring, 3: full_connected, 4: Nearest Neighbors: ) : ')
useTsne=0; %input('Apply t-SNE (0:No, 1:Yes) : ')
predictionMethod=input('Choose a prediction method (0: Kmeans, 1:SVDD/OC-SVM, 2: FitcSVM (Matlab built-in fct)), 3: Autoencoder, 4: Isolation Forest) ')

%%%%%%%%% Load extracted features and labels %%%%%%%%%%%%%%%%%
framedur=input('Give frame duration (sec): ');
shift=input('Give shift rate (between 0.01 and 0.5): ');
load (strcat(['C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniLR\RTS\Data\Matrix_signal_frame_Mel-log-features_',num2str(framedur),'_sec_shift_',num2str(shift),'.mat']));    
load (strcat(['C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniLR\RTS\Data\Matrix_signal_frame_labels_',num2str(framedur),'_sec_shift_',num2str(shift),'.mat']));     

%%%%%%%%%%%%%%%%%% Features %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=size(mel_log_features);
Features=reshape(mel_log_features,M(1)*M(2)*M(3),M(4)*M(5));
MFCC=mel_log_features(:,:,1,:,:);
MFCC=reshape(MFCC,size(MFCC,1)*size(MFCC,2)*size(MFCC,3),size(MFCC,4)*size(MFCC,5));
DcaseFeatures=MFCC.';

%%%%%%%% Labels %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Events=reshape(frame_event,M(4)*M(5),1);
Events=Events.';
Labels(Events<0)=0;
Labels(Events>=0)=1;
numfiles=size(Labels,2);

%%%%%%%% Graph %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% T=64;
% frameLength=T;
% frameShift=T/4;
% NFFT=2^nextpow2(T);
% normalize = 1/sqrt(NFFT);
% N=size(DcaseFeatures,2);

numfiles2=input(['Give the n. of audio files (max ',num2str(numfiles),') : '])
indexfiles=randi([1 numfiles], numfiles2,1);

WorkFeatures=DcaseFeatures(indexfiles,:);
WorkLabels=Labels(indexfiles).';
        
for n=1:numfiles2
        display(['Processing file No ', num2str(n),' of ',num2str(numfiles2)])        
        s=WorkFeatures(n,:);              
        
%         switch graphType
%             case 0
%                 G = gsp_sensor(N);
%             case 1
%                 G = gsp_path(N);
%             case 2
%                 G = gsp_ring(N);
%             case 3
%                 G = gsp_full_connected(N);
%             case 4
%                 %param.type='knn';
%                 %G=gsp_nn_graph(WorkFeatures', param);
%                 G=gsp_nn_graph(WorkFeatures');
%                 gsp_plot_graph(G)
%         end
%         G.jtv.NFFT=NFFT;
%         G.jtv.transform='dft';
%         G1 = gsp_compute_fourier_basis(G);
%         
% 
%         shat=gsp_jft(G1,s');
%         shat=abs(shat);
         shat=s;
         DcaseChunk(n,:)=reshape(shat,size(shat,1)*size(shat,2),1);
        clear s shat
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Apply t-SNE for data distribution %%%%%%%%%%%%%%%
if (useTsne==1)
    %Parameters
    no_dims=3;
    initial_dims=30;
    perplexity=30;
    labels=WorkLabels;
    %Apply tSNE
    mappedX=tsne(DcaseChunk,[],no_dims,initial_dims,perplexity);
    %figure, gscatter(mappedX(:,1),mappedX(:,2),labels);
    ydata=mappedX;
    figure
    if no_dims == 1
                scatter(ydata, ydata, 9, labels, 'filled');
        elseif no_dims == 2
                scatter(ydata(:,1), ydata(:,2), 9, labels, 'filled');
        else
                scatter3(ydata(:,1), ydata(:,2), ydata(:,3), 40, labels, 'filled');                
    end
    axis tight
    axis off
    drawnow
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% Apply K-means %%%%%%%%%%%%%%%%%%%
if (predictionMethod==0)
    %[idx,Cent]=kmeans(DcaseChunk,2);
    [idx,Cent]=kmeans(DcaseChunk,2);
    Pred=idx-1;
    target=WorkLabels;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);
end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%% Apply SVDD for OC-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==1)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);

    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';

    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';

    % parameter setting
    kernel = Kernel('type', 'gaussian', 'gamma', 0.04);
    cost = 0.3;
    svddParameter = struct('cost', cost,...
                           'kernelFunc', kernel);

    % creat an SVDD object
    svdd = BaseSVDD(svddParameter);
    % train SVDD model
    svdd.train(trainDataNormal, trainLabelNormal);
    %svdd.train(trainData, trainLabel);
    % test SVDD model
    results = svdd.test(testData, testLabel);
    % Visualization 
    svplot = SvddVisualization();
    %svplot.boundary(svdd);
    %svplot.ROC(svdd);
    %svplot.distance(svdd, results);
    %svplot.testDataWithBoundary(svdd, results);

    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    YPred = results.predictedLabel;
    Pred(YPred==-1)=1;
    Pred(YPred==1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);

    % Visualization 
    svplot = SvddVisualization();
    % svplot.boundary(svdd);
    svplot.distance(svdd, results);
    % svplot.testDataWithBoundary(svdd, results);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Apply fitSVM for OC-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==2)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);

    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';

    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;
    rng(1);
    %SVMModel = fitcsvm(trainDataNormal,trainLabelNormal,'KernelScale','auto','Standardize',true,...
    %'OutlierFraction',0.11);
    SVMModel = fitcsvm(trainData,trainLabel,'KernelScale','auto','Standardize',true,...
    'OutlierFraction',0.15);

    target(testLabel==-1)=1;
    target(testLabel==1)=0;

%     % Visualization 
%     svplot = SvddVisualization();
%     % svplot.boundary(svdd);
%     svplot.distance(svdd, results);
%     % svplot.testDataWithBoundary(svdd, results);
    svInd = SVMModel.IsSupportVector;
    %h = 0.02; % Mesh grid step size
    %[X1,X2] = meshgrid(min(testData(:,1)):h:max(testData(:,1)),...
    %    min(testData(:,2)):h:max(testData(:,2)));
    %[~,score] = predict(SVMModel,[X1(:),X2(:)]);
    [YPred,score] = predict(SVMModel,testData);
    Pred(YPred == -1)=1;
    Pred(YPred == 1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);

    %scoreGrid = reshape(score,size(X1,1),size(X2,2));

    %figure
    %plot(testData(:,1),testData(:,2),'k.')
    %hold on
    %plot(X(svInd,1),X(svInd,2),'ro','MarkerSize',10)
    %contour(X1,X2,scoreGrid)
    %colorbar;
    %title('{\bf Iris Outlier Detection via One-Class SVM}')
    %xlabel('Sepal Length (cm)')
    %ylabel('Sepal Width (cm)')
    %legend('Observation','Support Vector')
    %hold off
end

%%%%%%%%%%%% Method n.3-Apply AE for Anomaly Detection %%%%%%%%%%%%%%%%%%%
if (predictionMethod==3)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;
    rng(1);

    % Defined the training and test data
    traindata_ae = trainData.';
    testdata_ae = testData.';

    %Setup Autoencoder options
    option.MaxEpochs = input('Give max Epochs number; ');
    option.hiddenSize = input('Give number of hidden nodes: '); % number of hidden nodes, i.e. the dimension of the "code"
    option.L2WeightRegularization = 1.0e-10;
    option.SparsityRegularization = 1.0e-10;
    option.SparsityProportion = 0.7;
    option.ScaleData = true;
    option.UseGPU = false

    % Train the autoencoder
    autoenc = trainAutoencoder(traindata_ae, option.hiddenSize, ...
    'MaxEpochs', option.MaxEpochs, ...
    'L2WeightRegularization', option.L2WeightRegularization, ...
    'SparsityRegularization', option.SparsityRegularization, ...
    'SparsityProportion', option.SparsityProportion, ...
    'ScaleData', option.ScaleData, ...
    'UseGPU', option.UseGPU);

    %Do the encode-decode
    %Let's take one frame of data and feed it into the trained network. Let's then visualize the input, the code, the output and the error between input and output. We see that the trained network can reproduce the input pattern and noise is removed (autoencoders can also be used for denoising!)
    code = encode(autoenc,testdata_ae(:,1));
    decoded = decode(autoenc,code);
    tiledlayout('flow')
    nexttile
    plot(testdata_ae(:,1)),title('Input')
    nexttile
    plot(code),title('Code')
    nexttile
    plot(decoded),title('Output')
    nexttile
    plot(testdata_ae(:,1)-decoded), title('Error')
    %runAutoencoderDetection(testdata_ae,autoenc)

    %Calculate the error for the entire test set and visualize
    %Let's now test with the entire dataset and see if our network can spot the anomaly. And indeed wee see that it can.
    % Make a prediction with the entire test dataset
    y_hat = predict(autoenc, testdata_ae);
    % Calculate the error
    E1 = sqrt(sum((y_hat - testdata_ae).^2));
    X1_hat = y_hat(1, :);
    % Plot
    %ax1 = subplot(2, 1, 1);
    %plot(1:size(testdata_ae,2), testdata_ae, 1:size(X1_hat,2), X1_hat, 'LineWidth',1.5), legend('Measured','Predicted')
    %ax2 = subplot(2, 1, 2);
    figure
    plot(1:size(E1,2), E1, 'LineWidth',1.5), xlabel('test samples'), ylabel('RMSE'), legend('Error')
    %linkaxes([ax1 ax2],'x')
    
    %Run the detector sample by sample
    %runDetection
    
    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    
    % svInd = SVMModel.IsSupportVector;
    % [YPred,score] = predict(SVMModel,testData);
    % Pred(YPred == -1)=1;
    % Pred(YPred == 1)=0;
    % Pred=reshape(Pred,length(Pred),1);
    % target=reshape(target,length(target),1);
    Tau = input('Give the AE error threshold: ');
    YPred = E1>Tau;
    Pred = YPred.';
    
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%% Apply Isolation Forest for neovelty detection %%%%%%%%%%%%%%%%%%
if (predictionMethod==4)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);

    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';

    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;

    rng("default") % For reproducibility
    [Mdl,tf,s] = iforest(trainDataNormal);    

    target(testLabel==-1)=1;
    target(testLabel==1)=0;

    [tf_test,s_test] = isanomaly(Mdl,testData);
    Pred = tf_test;
    %Pred(YPred == -1)=1;
    %Pred(YPred == 1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Calculate evaluation metrics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[c,CM,ind,per]=confusion(target',Pred');
display(['Confusion matrix = '])
CM

Acc=1-c;
display(['Accuracy = ',num2str(Acc)])

numClasses=max(Labels)-min(Labels)+1;
for i=1:numClasses
    Prec(i)=CM(i,i)/sum(CM(i,:));
    Rec(i)=CM(i,i)/sum(CM(:,i));
    F1(i)=2*Prec(i)*Rec(i)/(Prec(i)+Rec(i));    
end

Acc=trace(CM)/length(target);
display('Confusion matrix: ')
display(CM)
% display(['Accuracy_FS = ',num2str(Acc)])
% display(['Precision_FS = ',num2str(Prec)])
% display(['Recall_FS = ',num2str(Rec)])
% display(['F1score_FS = ',num2str(F1)])

[tpr,fpr,thresholds] = roc(target',Pred');
figure
res=plotroc(target',Pred','grid');
grid on
auc=trapz([0,fpr,1],[0,tpr,1]);
%display(['AUC score = ',num2str(auc)])

Metrics=zeros(5,2)
Metrics(1,:)=[auc,0];
Metrics(2,:)=[Acc,0];
Metrics(3,:)=Prec;
Metrics(4,:)=Rec;
Metrics(5,:)=F1;
display(Metrics)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Apply tSNE for test Data %%%%%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if useTsne
    no_dims=8;
    initial_dims=min(length(target),30);
    perplexity=30;
    labels=target;
    %Apply tSNE
    mappedX=tsne(testData,[],no_dims,initial_dims,perplexity);
    figure, gscatter(mappedX(:,1),mappedX(:,2),labels);
end

%[reduction, umap, clusterIdentifiers, extras]=run_umap(DcaseChunk);
