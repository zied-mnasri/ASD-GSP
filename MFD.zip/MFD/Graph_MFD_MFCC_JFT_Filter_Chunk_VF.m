clear all
close all

addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\SVDD-MATLAB-master\')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\tSNE_matlab')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\SVDD-MATLAB-master\SVDD-MATLAB-master\Svdd')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\utils')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\graphs')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\filters')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\sgwt_require')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\plotting')
addpath('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\gspbox-0.7.5\gspbox\operators')

useGraph = 1; %input('Select Use Graph (1), No Graph (0): ')
if useGraph
    graphType=input('Select a graph type (0: sensor, 1: path, 2: ring, 3: full_connected, 4: Nearest Neighbors, 5: Erdos-Renyi) : ')
    useGraphFilter=1; %input('Use graph filtering (0:No, 1:Yes) : ');
    if useGraphFilter
        graph_filter_type=0; %input('Select a graph filter type (even if you don''t use Fraph filters (0: Simple TF filter, 1: Expwin filter): ')
    end
end

    
% if useGraphFilter==1    
%     filterType=1;%input('Select filter type (0: expwin, 1: simple_TF_wavelet, 2: Mexican_hat) ')
% end

useTsneTrain=0; %input('Apply t-SNE before training (0:No, 1:Yes) : ');
useTsneTest=0; %input('Apply t-SNE after test (0:No, 1:Yes) : ');
%useData=0;%input('Use clean/noisy/mix outliers (0:Clean, 1:Noisy, 2:Mix): '); 
predictionMethod=3; %input('Choose a prediction method (0: Kmeans (Casual!), 1:SVDD/OC-SVM, 2:FitcSVM/Bin-SVM), 3: Autoencoder, 4: Isolation forest ')
% if predictionMethod == 3
%     Tau = input('Give the AE error threshold: ')
% end

downSampleRate=1; %input('Give features downsample rate: ');
framedur=1; %input('Give frame duration (sec): ');
%%%%%%%%% Load extracted features and labels %%%%%%%%%%%%%%%%%

%dataDirectory=('C:\Users\ziedm\Desktop\TempDocs\Research\Projects\Music\Data\');
SNRdB=-6;%input('Give noise level in dB: ')
machineType='fan'; %input('Give machine type, eg. fan: ')
machineId=6;%input('Give Machine id (e.g 0, 2, 4, 6): ')
%machine_noise_type=input('Give noise dB and machine type, e.g. (6_dB_fan): ');
%waveDirectory=('C:\Users\ziedm\Desktop\TempDocs\Research\Projects\UniLR\MFD\Data\6_dB_fan\fan\id_06\');
dataDirectory=('C:\Users\zmnasri\OneDrive - University of Bradford\Desktop\Research\Projects\UniLR\MFD\Data\Features_Labels\');

%switch useData
%    case 0
        %load ([dataDirectory,'Features_Labels_Clean\MFCC_Features_Labels_',num2str(framedur),'sec_clean.mat'])
%        load([dataDirectory,'MFCC_Features_Labels_',num2str(SNRdB),'_dB_',machineType,'_',num2str(framedur),'sec.mat'])
load ([dataDirectory,'MFCC_Features_Labels_',num2str(SNRdB),'_dB_',machineType,'_id_0',num2str(machineId),'_',num2str(framedur),'sec.mat'])
%   case 1
%        noiseType=input('Give noise type ("white", "babble"): ')
%        SNRdB=0;%input('Give SNRdB: ')
        %load ([dataDirectory,'MFCC_Features_Labels_',num2str(framedur),'sec_noisy_babble_',num2str(SNRdB),'dB.mat'])
        %load ([dataDirectory,'MFCC_Features_Labels_',num2str(framedur),'sec_noisy_',noiseType,'_',num2str(SNRdB),'dB.mat'])
%        load ([dataDirectory,'Features_Labels_Noisy\MFCC_Features_Labels_',num2str(framedur),'sec_noisy_',noiseType,'_',num2str(SNRdB),'dB_Random.mat'])
%     case 2
%        load ([dataDirectory,'Features_Labels_Mix\MFCC_Features_Labels_',num2str(framedur),'sec_mix.mat'])
%end
    
%%%%%%%% Labels %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
numfiles=length(Outlierness);
numLabels=length(unique(Outlierness));
%numfiles=length(Outlierness);
%numLabels=length(unique(Outlierness));

% switch useData
%     case 0 %In this workspace, choose the outlier genre
%         outlier='classical';%input('Choose the outlier genre (blues,classical,country,disco,hiphop,jazz,metal,pop,reggae,rock): ');         
%     case 1 %In this workspace, 'classical' signals are noisy %
% %         outlier='classical';
         % outlier='abnormal';
%     %case 2 %In this workspace, 'classical' signals are noisy 
%     %    outlier='classical';
%     case 2 %In this workspace, 'genreMix' signals are outliers
%         outlier='genres_mix';
% end

% switch useData
%     case 0 %In this workspace, choose the outlier genre
%         %outlier=input('Choose the outlier genre (blues,classical,country,disco,hiphop,jazz,metal,pop,reggae,rock): ');         
%         Label(Genre==outlier)=1;
%         Label(Genre~=outlier)=0;
%     case 1 %In this workspace, noisy signals are the outlier %
%         Label(Outlierness==outlier)=1;
%         Label(Outlierness~=outlier)=0;
%     case 2 %In this workspace, 'genres_mix' signals are the outliers
%         Label(Genre==outlier)=1;
%         Label(Genre~=outlier)=0;
% end
Label(Outlierness=='abnormal')=1;
Label(Outlierness=='normal')=0;
outlierFraction=sum(Label==1)/length(Label)

% Label(Genre==outlier)=1;
% Label(Genre~=outlier)=0;
% Label(Outlierness==outlier)=1;
% Label(Outlierness~=outlier)=0;



numfiles2=1000;%input(['Give the n. of audio files (max ',num2str(numfiles),') : '])
indexfiles=randi([1 numfiles], numfiles2,1);
%indexfiles=(1:numfiles2);
WorkFeatures0=Features(indexfiles,:);
WorkFeatures=(downsample(WorkFeatures0.',downSampleRate)).';

WorkLabels=Label(indexfiles).';
N=size(WorkFeatures,2);
outlierFraction2=sum(WorkLabels==1)/length(WorkLabels)

%%%%%%%% Graph %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if useGraph
    fs=16000;
    T=64;
    frameLength=T;
    frameShift=T/4;
    NFFT=2^nextpow2(T);
    normalize = 1/sqrt(NFFT);
    %N=size(Features,2);
    WorkLabels=Label(indexfiles).';
    N=size(WorkFeatures,2);
    outlierFraction2=sum(WorkLabels==1)/length(WorkLabels)
    
    switch graphType
                case 0
                    G = gsp_sensor(N);
                case 1
                    G = gsp_path(N);
                case 2
                    G = gsp_ring(N);
                case 3
                    G = gsp_full_connected(N);
                case 4
                    %param.type='knn';
                    %G=gsp_nn_graph(WorkFeatures', param);
                    G=gsp_nn_graph(WorkFeatures');
                    %gsp_plot_graph(G)
                case 5
                    G = gsp_erdos_renyi(N,0.05);
    end
    
    G = gsp_jtv_graph(G,T,fs);
    G.jtv.NFFT=NFFT;
    G.jtv.transform='dft';
    G1 = gsp_compute_fourier_basis(G);
    
    Nf=6;
    g=gsp_design_simple_tf(G, Nf);
    order=6;
    ga=gsp_approx_filter(G1,g,order);
    param.order=order;
    % figure, gsp_plot_filter(G,ga);
    
    for n=1:numfiles2
            display(['Processing file No ', num2str(n),' of ',num2str(numfiles2)])        
            s=WorkFeatures(n,:);              
            
            if (useGraphFilter==1)
                shat=gsp_filter_evaluate(ga,s');
                shat=abs(gsp_jft(G1,shat));
            else 
                shat=gsp_jft(G1,s');
                shat=abs(shat);
            end
            DcaseChunk(n,:)=reshape(shat,size(shat,1)*size(shat,2),1);
            clear s shat
    end
else
    for n=1:numfiles2
        display(['Processing file No ', num2str(n),' of ',num2str(numfiles2)])        
        s=WorkFeatures(n,:);              
        shat=s;
        DcaseChunk(n,:)=reshape(shat,size(shat,1)*size(shat,2),1);
        clear s shat
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Apply t-SNE for data distribution %%%%%%%%%%%%%%%
if (useTsneTrain==1)
    %Parameters
    no_dims=3;
    initial_dims=30;
    perplexity=30;
    labels=WorkLabels;
    %Apply tSNE
    mappedX=tsne(DcaseChunk,[],no_dims,initial_dims,perplexity);
    figure, gscatter(mappedX(:,1),mappedX(:,3),labels);
    %figure, gscatter(mappedX(:,1),mappedX(:,3),Genre(indexfiles(1:numfiles2)));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% Apply K-means %%%%%%%%%%%%%%%%%%%
if (predictionMethod==0)
    [idx,Cent]=kmeans(DcaseChunk,2);
    Pred=idx-1;
    target=WorkLabels;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Apply SVDD for OC-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==1)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    
    % parameter setting
    kernel = Kernel('type', 'gaussian', 'gamma', 0.04);
    cost = 0.3;
    svddParameter = struct('cost', cost,...
                           'kernelFunc', kernel);

    % creat an SVDD object
    svdd = BaseSVDD(svddParameter);
    % train SVDD model
    svdd.train(trainDataNormal, trainLabelNormal);
    %svdd.train(trainData, trainLabel);
    % test SVDD model
    results = svdd.test(testData, testLabel);
    % Visualization 
    %svplot = SvddVisualization();
    %svplot.boundary(svdd);
    %svplot.ROC(svdd);
    %svplot.distance(svdd, results);
    %svplot.testDataWithBoundary(svdd, results);

    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    YPred = results.predictedLabel;
    Pred(YPred==-1)=1;
    Pred(YPred==1)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);
    
    % Visualization 
    % svplot = SvddVisualization();
    % svplot.boundary(svdd);
    % svplot.distance(svdd, results);
    % svplot.testDataWithBoundary(svdd, results);

end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%% Apply fitSVM for Binary-SVM %%%%%%%%%%%%%%%%%%%
if (predictionMethod==2)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=0;
    label(label1==1)=1;
    normalData=data(label==0,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    
    trainData=data(randIdx(1:Trainsize),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    
    target=testLabel;
    rng(1);
    SVMModel = fitcsvm(trainData,trainLabel,'KernelScale','auto','Standardize',true,...
    'OutlierFraction',outlierFraction2);
    
    svInd = SVMModel.IsSupportVector;
    %h = 0.02; % Mesh grid step size
    %[X1,X2] = meshgrid(min(testData(:,1)):h:max(testData(:,1)),...
    %    min(testData(:,2)):h:max(testData(:,2)));
    %[~,score] = predict(SVMModel,[X1(:),X2(:)]);
    [YPred,score] = predict(SVMModel,testData);
    Pred(YPred == 1)=1;
    Pred(YPred == 0)=0;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);    
    %scoreGrid = reshape(score,size(X1,1),size(X2,2));

    %figure
    %plot(testData(:,1),testData(:,2),'k.')
    %hold on
    %plot(X(svInd,1),X(svInd,2),'ro','MarkerSize',10)
    %contour(X1,X2,scoreGrid)
    %colorbar;
    %title('{\bf Iris Outlier Detection via One-Class SVM}')
    %xlabel('Sepal Length (cm)')
    %ylabel('Sepal Width (cm)')
    %legend('Observation','Support Vector')
    %hold off
end

%%%%%%%%%%%% Method n.3-Apply AE for Anomaly Detection %%%%%%%%%%%%%%%%%%%
if (predictionMethod==3)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;
    rng(1);

    % Defined the training and test data
    traindata_ae = trainDataNormal.';
    testdata_ae = testData.';

    %Setup Autoencoder options
    if useGraph
        option.MaxEpochs = 10; %input('Give number of epochs: ')
    else
        option.MaxEpochs = 10; %input('Give number of epochs: ')
    end
    option.hiddenSize = round(numfiles2/10); %input('Give number of hidden nodes: ')% number of hidden nodes, i.e. the dimension of the "code"
    option.L2WeightRegularization = 1.0e-10;
    option.SparsityRegularization = 1.0e-10;
    option.SparsityProportion = 0.7;
    option.ScaleData = true;
    option.UseGPU = false

    % Train the autoencoder
    autoenc = trainAutoencoder(traindata_ae, option.hiddenSize, ...
    'MaxEpochs', option.MaxEpochs, ...
    'L2WeightRegularization', option.L2WeightRegularization, ...
    'SparsityRegularization', option.SparsityRegularization, ...
    'SparsityProportion', option.SparsityProportion, ...
    'ScaleData', option.ScaleData, ...
    'UseGPU', option.UseGPU);

    %Do the encode-decode
    %Let's take one frame of data and feed it into the trained network. Let's then visualize the input, the code, the output and the error between input and output. We see that the trained network can reproduce the input pattern and noise is removed (autoencoders can also be used for denoising!)
    code = encode(autoenc,testdata_ae(:,1));
    decoded = decode(autoenc,code);
    tiledlayout('flow')
    nexttile
    plot(testdata_ae(:,1)),title('Input')
    nexttile
    plot(code),title('Code')
    nexttile
    plot(decoded),title('Output')
    nexttile
    plot(testdata_ae(:,1)-decoded), title('Error')
    %runAutoencoderDetection(testdata_ae,autoenc)

    %Calculate the error for the entire test set and visualize
    %Let's now test with the entire dataset and see if our network can spot the anomaly. And indeed wee see that it can.
    % Make a prediction with the entire test dataset
    y_hat = predict(autoenc, testdata_ae);
    % Calculate the error
    E1 = sqrt(sum((y_hat - testdata_ae).^2));
    X1_hat = y_hat(1, :);
    % Plot
    %ax1 = subplot(2, 1, 1);
    %plot(1:size(testdata_ae,2), testdata_ae, 1:size(X1_hat,2), X1_hat, 'LineWidth',1.5), legend('Measured','Predicted')
    %ax2 = subplot(2, 1, 2);
    figure
    plot(1:size(E1,2), E1, 'LineWidth',1.5), legend('Error'), xlabel('Test samples'), ylabel('RMSE')
    grid on
    %linkaxes([ax1 ax2],'x')
    
    %Run the detector sample by sample
    %runDetection

    target(testLabel==-1)=1;
    target(testLabel==1)=0;
    
    % svInd = SVMModel.IsSupportVector;
    % [YPred,score] = predict(SVMModel,testData);
    % Pred(YPred == -1)=1;
    % Pred(YPred == 1)=0;
    % Pred=reshape(Pred,length(Pred),1);
    % target=reshape(target,length(target),1);
    Tau = max(mean(E1),median(E1));%median(E1) %input('Give the AE error threshold: ')
    YPred = E1>Tau;
    Pred = YPred.';
    
end

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%% Apply Isolation Forest for neovelty detection %%%%%%%%%%%%%%%%%%
if (predictionMethod==4)
    data=DcaseChunk;
    label1=WorkLabels;
    label(label1==0)=1;
    label(label1==1)=-1;
    normalData=data(label==1,:);
    numfilesNormal=size(normalData,1);

    randIdx=randperm(numfiles2);
    Trainsize=floor(0.8*numfiles2);
    Testsize=floor(0.2*numfiles2);

    randIdxNormal=randperm(numfilesNormal);
    TrainsizeNormal=floor(0.8*numfilesNormal);
    TestsizeNormal=floor(0.2*numfilesNormal);

    trainData=data(randIdx(1:Trainsize),:,:);
    trainDataNormal=normalData(randIdxNormal(1:TrainsizeNormal),:,:);
    testData=data(randIdx(Trainsize+1:Trainsize+Testsize),:,:);
    
    trainLabel=label(randIdx(1:Trainsize));
    trainLabelNormal=ones(size(trainDataNormal,1),1);
    trainLabel=trainLabel.';
    
    testLabel=label(randIdx(Trainsize+1:Trainsize+Testsize));
    testLabel=testLabel.';
    target=testLabel;

    rng("default") % For reproducibility
    [Mdl,tf,s] = iforest(trainDataNormal); 
    %[Mdl,tf,s] = iforest(trainData,ContaminationFraction=outlierFraction2);  % Outlier detrection (two-class)

    target(testLabel==-1)=1;
    target(testLabel==1)=0;

    [tf_test,s_test] = isanomaly(Mdl,testData);

    % Pred(YPred == -1)=1;
    % Pred(YPred == 1)=0;
    Pred = tf_test;
    Pred=reshape(Pred,length(Pred),1);
    target=reshape(target,length(target),1);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Calculate evaluation metrics %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[c,CM,ind,per]=confusion(target',Pred');
display(['Confusion matrix = '])
CM

Acc=1-c;
display(['Accuracy = ',num2str(Acc)])

numClasses=max(WorkLabels)-min(WorkLabels)+1;
    for i=1:numClasses
        Prec(i)=CM(i,i)/sum(CM(i,:));
        Rec(i)=CM(i,i)/sum(CM(:,i));
        F1(i)=2*Prec(i)*Rec(i)/(Prec(i)+Rec(i));    
    end

Acc=trace(CM)/length(target);
display('Confusion matrix: ')
display(CM)

[tpr,fpr,thresholds] = roc(target',Pred');
figure
res=plotroc(target',Pred','grid');
grid on
auc=trapz([0,fpr,1],[0,tpr,1]);
%display(['AUC score = ',num2str(auc)])

Metrics=zeros(5,2);
Metrics(1,:)=[auc,0];
Metrics(2,:)=[Acc,0];
Metrics(3,:)=Prec;
Metrics(4,:)=Rec;
Metrics(5,:)=F1;
%display([['AUC      ';'Accuracy ';'Precision';'Recall   ';'F1-score '],num2str(round(Metrics,2))])
%Metrics
display(Metrics)
if predictionMethod == 3
    display (['Tau = ',num2str(Tau)])
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% Apply tSNE for test Data %%%%%%% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if (useTsneTest==1)
    no_dims=3;
    initial_dims=min(length(Pred),30);
    perplexity=30;
    %labels=Pred;
    labels=target;
    %Apply tSNE
    mappedX=tsne(testData,[],no_dims,initial_dims,perplexity);
    figure, gscatter(mappedX(:,1),mappedX(:,3),labels);
    %figure, gscatter(mappedX(:,1),mappedX(:,3),Genre(indexfiles(Trainsize+1:Trainsize+Testsize)));
end

